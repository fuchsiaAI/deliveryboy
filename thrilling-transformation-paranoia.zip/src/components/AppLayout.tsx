import { HeroSection } from './book/HeroSection';
import { AboutSection } from './book/AboutSection';
import { AuthorSection } from './book/AuthorSection';
import { ChaptersSection } from './book/ChaptersSection';
import { TestimonialsSection } from './book/TestimonialsSection';
import { PurchaseSection } from './book/PurchaseSection';
import { NewsletterSection } from './book/NewsletterSection';
import { PressSection } from './book/PressSection';
import { Footer } from './book/Footer';

export default function AppLayout() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <AboutSection />
      <ChaptersSection />
      <TestimonialsSection />
      <AuthorSection />
      <PurchaseSection />
      <NewsletterSection />
      <PressSection />
      <Footer />
    </div>
  );
}
