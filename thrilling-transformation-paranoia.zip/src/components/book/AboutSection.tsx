export function AboutSection() {
  const highlights = [
    { icon: "🌃", title: "Dark Urban Thriller", text: "A gritty exploration of Orlando's underground scene" },
    { icon: "💔", title: "Forbidden Romance", text: "A dangerous attraction that blurs all boundaries" },
    { icon: "⚡", title: "High-Stakes Drama", text: "Power, betrayal, and the cost of ambition" },
    { icon: "🎭", title: "Complex Characters", text: "Morally gray protagonists you can't look away from" }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-12 font-serif text-slate-900">About the Book</h2>
        
        <div className="max-w-4xl mx-auto mb-16">
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            Evan Cole, a lonely nineteen-year-old UCF freshman, stumbles into the orbit of Damian Rhodes, a charismatic dealer whose charm and chaos prove irresistible. What begins as a flirtatious DoorDash drop spirals into a double life—campus student by day, trusted runner by night.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            Tempted by money, intimacy, and the rush of belonging, Evan slips deeper into a world he never imagined. With Jazz Porter as the lone voice of conscience and a detective circling closer, the stakes rise higher with every choice.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed">
            As power and paranoia collide, Evan must face the ultimate question: How far will he go for love, money, and a place to belong? And when the line between right and wrong disappears, can he find his way back?
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, idx) => (
            <div key={idx} className="bg-gradient-to-br from-purple-50 to-slate-50 p-6 rounded-lg hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-3">{item.icon}</div>
              <h3 className="text-xl font-bold mb-2 text-slate-900">{item.title}</h3>
              <p className="text-gray-600">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
