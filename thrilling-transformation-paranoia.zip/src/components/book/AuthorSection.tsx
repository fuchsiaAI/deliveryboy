import { Instagram } from 'lucide-react';
export function AuthorSection() {
  const socialLinks = [{
    name: 'Twitter',
    url: 'https://twitter.com',
    icon: '𝕏'
  }, {
    name: 'Instagram',
    url: 'https://instagram.com/dylanbemerson',
    icon: <Instagram className="w-6 h-6" />
  }, {
    name: 'TikTok',
    url: 'https://tiktok.com/@dylanbemerson',
    icon: <img src="https://d64gsuwffb70l.cloudfront.net/68dc48eddc1b1429515936c2_1759563743992_1e307523.jpeg" alt="TikTok" className="w-6 h-6" />
  }, {
    name: 'Goodreads',
    url: 'https://goodreads.com',
    icon: '📚'
  }];
  return <section id="author" className="py-20 bg-gradient-to-br from-slate-900 to-purple-900 text-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-12 font-serif">Meet the Author</h2>
        
        <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-12 items-center">
          <div className="md:col-span-1 flex justify-center">
            <img src="https://d64gsuwffb70l.cloudfront.net/68dc48eddc1b1429515936c2_1759561525135_af40e955.jpeg" alt="Dylan B. Emerson" className="w-48 h-48 md:w-56 md:h-56 rounded-lg object-cover shadow-2xl" />
          </div>

          
          <div className="md:col-span-2">
            <h3 className="text-3xl font-bold mb-4">Dylan B. Emerson</h3>
            <p className="text-lg text-gray-300 leading-relaxed mb-4">
              Dylan B. Emerson is an emerging voice in contemporary fiction, known for crafting raw, unflinching narratives that explore the darker corners of American youth culture.
            </p>
            <p className="text-lg text-gray-300 leading-relaxed mb-4">
              Drawing from personal observations of college life and urban subcultures, he writes with an authenticity that resonates with readers seeking stories that don't shy away from complexity and moral ambiguity.
            </p>
            <p className="text-lg text-gray-300 leading-relaxed mb-6">
              <em>Delivery Boy</em> marks his debut novel, a gripping exploration of ambition, desire, and the price of belonging in a world that offers everything except safety.
            </p>
            
            <div className="mb-6">
              <h4 className="text-xl font-semibold mb-3">Connect</h4>
              <a href="https://tiktok.com/@dylanbemerson" target="_blank" rel="noopener noreferrer" className="text-purple-300 hover:text-purple-400 transition-colors inline-flex items-center gap-2">
                <img src="https://d64gsuwffb70l.cloudfront.net/68dc48eddc1b1429515936c2_1759563743992_1e307523.jpeg" alt="TikTok" className="w-5 h-5" />
                @dylanbemerson
              </a>
            </div>


            <div className="flex gap-4">
              {socialLinks.map((link, idx) => <a key={idx} href={link.url} target="_blank" rel="noopener noreferrer" className="text-2xl hover:text-purple-400 transition-colors" aria-label={link.name}>
                  {link.icon}
                </a>)}
            </div>

          </div>
        </div>
      </div>
    </section>;
}