export function ChaptersSection() {
  const chapters = [
    {
      title: "The First Drop",
      excerpt: "The apartment door opened to reveal someone Evan hadn't expected. Dark eyes, easy smile, and a presence that filled the doorway. 'You're early,' Damian said, and everything changed.",
      image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537673233_67ce9792.webp"
    },
    {
      title: "Double Life",
      excerpt: "By day, he was just another student in the lecture hall. By night, the city knew his name. The money piled up, and so did the lies.",
      image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537673935_3d6e9def.webp"
    },
    {
      title: "The Party",
      excerpt: "Neon lights painted everything purple. Bodies pressed close, music pounding. Damian's hand on his shoulder felt like ownership. Evan didn't pull away.",
      image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537674657_90075eaf.webp"
    },
    {
      title: "Closing In",
      excerpt: "Detective Morrison had a file with Evan's name on it. The net was tightening, but Evan was too deep to see it. Or maybe he just didn't want to.",
      image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537675449_1775c321.webp"
    },
    {
      title: "Empire of Ash",
      excerpt: "He'd built something bigger than Damian ever dreamed. But empires built on sand don't stand for long, and the betrayals were coming from inside.",
      image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537673935_3d6e9def.webp"
    },
    {
      title: "The Reckoning",
      excerpt: "Everything Evan built is crumbling. The choices he made are catching up. In the darkness of Orlando's summer night, one final decision will determine his fate.",
      image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537676287_14fe77d9.webp"
    }
  ];

  return (
    <section id="chapters" className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 font-serif text-slate-900">Inside the Story</h2>
        <p className="text-center text-gray-600 mb-12 text-lg">Preview key moments from Evan's descent</p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {chapters.map((chapter, idx) => (
            <div key={idx} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-shadow group">
              <div className="h-48 overflow-hidden">
                <img 
                  src={chapter.image} 
                  alt={chapter.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3 text-slate-900">{chapter.title}</h3>
                <p className="text-gray-600 leading-relaxed italic">{chapter.excerpt}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
