export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-bold mb-4 font-serif">Delivery Boy</h3>
            <p className="text-gray-400">by Dylan B. Emerson</p>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><button onClick={() => scrollToSection('about')} className="text-gray-400 hover:text-white transition-colors">About</button></li>
              <li><button onClick={() => scrollToSection('author')} className="text-gray-400 hover:text-white transition-colors">Author</button></li>
              <li><button onClick={() => scrollToSection('chapters')} className="text-gray-400 hover:text-white transition-colors">Chapters</button></li>
              <li><button onClick={() => scrollToSection('reviews')} className="text-gray-400 hover:text-white transition-colors">Reviews</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Get the Book</h4>
            <ul className="space-y-2">
              <li><button onClick={() => scrollToSection('purchase')} className="text-gray-400 hover:text-white transition-colors">Purchase</button></li>
              <li><button onClick={() => scrollToSection('press')} className="text-gray-400 hover:text-white transition-colors">Press Kit</button></li>
              <li><button onClick={() => scrollToSection('newsletter')} className="text-gray-400 hover:text-white transition-colors">Newsletter</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Connect</h4>
            <ul className="space-y-2">
              <li><a href="https://www.tiktok.com/@dylanbemerson" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">TikTok</a></li>
              <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">Twitter</a></li>
              <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">Instagram</a></li>
              <li><a href="https://goodreads.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">Goodreads</a></li>
            </ul>

          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-400 text-sm mb-4 md:mb-0">
            <p>© 2025 Dylan B. Emerson. All rights reserved.</p>
            <p className="mt-1">Media inquiries: <a href="mailto:contact@dylanemerson.com" className="text-purple-400 hover:text-purple-300 transition-colors">contact@dylanemerson.com</a></p>
          </div>

          <button onClick={scrollToTop} className="text-purple-400 hover:text-purple-300 transition-colors">
            ↑ Back to Top
          </button>
        </div>
      </div>
    </footer>
  );
}
