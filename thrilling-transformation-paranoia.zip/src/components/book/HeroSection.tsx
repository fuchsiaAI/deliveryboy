import { Button } from '@/components/ui/button';

export function HeroSection() {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759537673233_67ce9792.webp" 
          alt="Background" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1 text-white">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 font-serif">Delivery Boy</h1>
            <p className="text-xl md:text-2xl mb-4 text-purple-200">by Dylan B. Emerson</p>
            <p className="text-lg md:text-xl mb-8 text-gray-300 leading-relaxed">
              A lonely college freshman. A charismatic dealer. One DoorDash delivery that changes everything.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" onClick={() => scrollToSection('purchase')} className="bg-purple-600 hover:bg-purple-700">
                Buy Now
              </Button>
              <Button size="lg" variant="outline" onClick={() => scrollToSection('about')} className="border-white text-white hover:bg-white hover:text-purple-900">
                Read More
              </Button>
            </div>
          </div>
          
          <div className="order-1 md:order-2 flex justify-center">
            <img 
              src="https://d64gsuwffb70l.cloudfront.net/68dc48eddc1b1429515936c2_1759551393805_3b4f6272.png" 
              alt="Delivery Boy Book Cover" 
              className="w-full max-w-md shadow-2xl rounded-lg transform hover:scale-105 transition-transform duration-300"
            />
          </div>

        </div>
      </div>
    </section>
  );
}
