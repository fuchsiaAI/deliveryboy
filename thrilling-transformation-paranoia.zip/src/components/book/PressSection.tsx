import { Button } from '@/components/ui/button';

export function PressSection() {
  const downloads = [
    { name: 'High-Res Book Cover', size: '2.4 MB', format: 'PNG' },
    { name: 'Author Photo', size: '1.8 MB', format: 'JPG' },
    { name: 'Press Release', size: '156 KB', format: 'PDF' },
    { name: 'Media Kit', size: '4.2 MB', format: 'ZIP' }
  ];

  const handleDownload = (item: string) => {
    alert(`Downloading ${item}... (Demo - no actual file)`);
  };

  return (
    <section id="press" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 font-serif text-slate-900">Press Kit</h2>
        <p className="text-center text-gray-600 mb-12 text-lg">Resources for media, bloggers, and reviewers</p>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {downloads.map((item, idx) => (
              <div key={idx} className="bg-gradient-to-br from-purple-50 to-slate-50 rounded-lg p-6 flex items-center justify-between hover:shadow-lg transition-shadow">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">{item.name}</h3>
                  <p className="text-gray-600">{item.format} • {item.size}</p>
                </div>
                <Button onClick={() => handleDownload(item.name)} variant="outline" className="ml-4">
                  Download
                </Button>
              </div>
            ))}
          </div>

          <div className="bg-slate-900 text-white rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Media Inquiries</h3>
            <p className="text-gray-300 mb-6">
              For interviews, review copies, or press inquiries, please contact:
            </p>
            <a href="mailto:press@deliveryboybook.com" className="text-purple-400 hover:text-purple-300 text-xl font-semibold">
              press@deliveryboybook.com
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
