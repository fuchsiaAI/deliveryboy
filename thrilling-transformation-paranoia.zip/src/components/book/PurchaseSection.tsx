import { Button } from '@/components/ui/button';

export function PurchaseSection() {
  const retailers = [
    { name: 'Amazon', url: 'https://books.by/dylan', icon: '📦' },
    { name: 'Barnes & Noble', url: 'https://barnesandnoble.com', icon: '📚' },
    { name: 'Books-A-Million', url: 'https://booksamillion.com', icon: '📖' },
    { name: 'IndieBound', url: 'https://indiebound.org', icon: '🏪' },
    { name: 'Apple Books', url: 'https://apple.com/books', icon: '🍎' },
    { name: 'Google Play', url: 'https://play.google.com/books', icon: '📱' }
  ];

  const formats = [
    { type: 'Hardcover', price: '$27.99', description: 'Premium edition with dust jacket' },
    { type: 'Paperback', price: '$16.99', description: 'Trade paperback edition' },
    { type: 'eBook', price: '$9.99', description: 'Instant digital download' },
    { type: 'Audiobook', price: '$24.99', description: 'Narrated by award-winning voice actor' }
  ];

  return (
    <section id="purchase" className="py-20 bg-gradient-to-br from-purple-900 to-slate-900 text-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 font-serif">Get Your Copy</h2>
        <p className="text-center text-purple-200 mb-12 text-lg">Available in multiple formats</p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {formats.map((format, idx) => (
            <div key={idx} className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/20 transition-colors">
              <h3 className="text-2xl font-bold mb-2">{format.type}</h3>
              <p className="text-3xl font-bold text-purple-300 mb-3">{format.price}</p>
              <p className="text-gray-300 text-sm">{format.description}</p>
            </div>
          ))}
        </div>

        <div className="max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold text-center mb-8">Available at these retailers:</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {retailers.map((retailer, idx) => (
              <Button
                key={idx}
                onClick={() => window.open(retailer.url, '_blank')}
                variant="outline"
                className="bg-white/10 border-white/30 hover:bg-white hover:text-purple-900 text-white h-16 text-lg"
              >
                <span className="mr-2">{retailer.icon}</span>
                {retailer.name}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
