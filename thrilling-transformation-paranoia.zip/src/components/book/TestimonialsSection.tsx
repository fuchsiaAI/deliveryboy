import { useState } from 'react';
import { Button } from '@/components/ui/button';

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const testimonials = [
    { name: "Sarah M.", rating: 5, text: "Absolutely gripping. I couldn't put it down. Emerson captures the descent into darkness with brutal honesty.", image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759561350529_ff1565d9.webp" },
    { name: "Marcus T.", rating: 5, text: "A modern tragedy that feels painfully real. The character work is phenomenal.", image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759561351308_bdaaf846.webp" },
    { name: "Jessica L.", rating: 5, text: "Dark, compelling, and impossible to forget. This book will haunt you.", image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759561353143_e873bb0f.webp" },
    { name: "David K.", rating: 4, text: "Emerson doesn't pull punches. Raw and unflinching storytelling at its finest.", image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759561353858_7949a65a.webp" },
    { name: "Amanda R.", rating: 5, text: "The best debut I've read in years. Evan's journey is heartbreaking and mesmerizing.", image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759561354613_60cc78cb.webp" },
    { name: "Jake W.", rating: 5, text: "A thriller that's also a love story, a cautionary tale, and a character study. Brilliant.", image: "https://d64gsuwffb70l.cloudfront.net/68e06997e1d87a70f3741eaa_1759561432669_e1352193.webp" }

  ];


  const next = () => setCurrentIndex((currentIndex + 1) % testimonials.length);
  const prev = () => setCurrentIndex((currentIndex - 1 + testimonials.length) % testimonials.length);

  return (
    <section id="reviews" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-12 font-serif text-slate-900">What Readers Are Saying</h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-purple-50 to-slate-50 rounded-lg p-8 md:p-12 shadow-xl">
            <div className="flex items-center gap-6 mb-6">
              <img 
                src={testimonials[currentIndex].image} 
                alt={testimonials[currentIndex].name}
                className="w-20 h-20 rounded-full object-cover"
              />
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{testimonials[currentIndex].name}</h3>
                <div className="text-yellow-500 text-xl">{'★'.repeat(testimonials[currentIndex].rating)}</div>
              </div>
            </div>
            <p className="text-xl text-gray-700 leading-relaxed italic mb-8">"{testimonials[currentIndex].text}"</p>
            
            <div className="flex justify-center gap-4">
              <Button onClick={prev} variant="outline">← Previous</Button>
              <Button onClick={next} variant="outline">Next →</Button>
            </div>
          </div>
          
          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`w-3 h-3 rounded-full transition-colors ${idx === currentIndex ? 'bg-purple-600' : 'bg-gray-300'}`}
                aria-label={`Go to review ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
